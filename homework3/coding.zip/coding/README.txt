James Russo and Shiven Srivastava
jdr289 and ss2654

There are no relevant comments about our code that we think we must make known to the graders. We followed the algorithms given to us by the book and homework document